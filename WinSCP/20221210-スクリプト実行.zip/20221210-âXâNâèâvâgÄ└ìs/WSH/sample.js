var sessionOptions = WScript.CreateObject("WinSCP.SessionOptions");

WScript.Echo("End.");
