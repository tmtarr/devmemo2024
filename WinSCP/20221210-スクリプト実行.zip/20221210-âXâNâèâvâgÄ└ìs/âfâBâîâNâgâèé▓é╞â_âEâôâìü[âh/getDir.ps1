# �ϐ��錾
$remotePath = "/home/yutaka/work/20221210/"
$localPath = (Get-Location).Path


# ���C������
function main {
	$localPath
	getDir($remotePath, $localPath)
	pause
}

function getDir {
	"called getDir func"
}


. main
