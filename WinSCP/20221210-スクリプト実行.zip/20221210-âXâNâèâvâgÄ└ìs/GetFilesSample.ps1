# session.GetFiles sample
try {
	# Load WinSCP .NET assembly
	Add-Type -Path "C:\Program Files (x86)\WinSCP\WinSCPnet.dll"
	
	# Setup session options
	$sessionOptions = New-Object WinSCP.SessionOptions -Property @{
		Protocol = [WinSCP.Protocol]::Sftp
		HostName = "172.23.231.78"
		UserName = "yutaka"
		Password = "yutakap"
		SshHostKeyFingerprint = "ssh-ed25519 256 A5WE/pmPzLhPkWYwqhyHEI0EM3hQCNWAzkb7PXpP9/s="
	}

	$session = New-Object WinSCP.Session

	try {
		# Connect
		$session.Open($sessionOptions)
		
		# Download files
		$transferOptions = New-Object WinSCP.TransferOptions
		$transferOptions.TransferMode = [WinSCP.TransferMode]::Binary
		
		$transferResult = $session.GetFiles("/home/yutaka/work/20221210/*"
			,"D:\doc\res\software\WinSCP\20221210-�X�N���v�g���s\"
			, $False
			, $transferOptions);

		# Throw on any error
		$transferResult.Check()

		# Print results
		foreach($transfer in $transferResult.Transfers) {
			Write-Host "Download of $($transfer.FileName) succeeded"
		}

	} finally {
		Write-Host "finally"
		$session.Dispose()
	}

} catch {
	Write-Host "Error"
	Write-Host "Error: $($_.Exception.Message)"
}
pause
